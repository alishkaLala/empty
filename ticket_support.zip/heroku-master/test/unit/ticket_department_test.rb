require 'test_helper'

class TicketDepartmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
