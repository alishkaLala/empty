require 'test_helper'

class TicketHistoriesHelperTest < ActionView::TestCase
end
