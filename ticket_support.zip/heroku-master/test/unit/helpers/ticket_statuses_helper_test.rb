require 'test_helper'

class TicketStatusesHelperTest < ActionView::TestCase
end
