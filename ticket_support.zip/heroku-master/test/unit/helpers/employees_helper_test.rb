require 'test_helper'

class EmployeesHelperTest < ActionView::TestCase
end
