require 'test_helper'

class SessionsControllerHelperTest < ActionView::TestCase
end
