require 'test_helper'

class TicketStatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
