# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Traking::Application.config.secret_token = '04281bc536d2f753d2e17c94c82f0e6faf834d4b759645ee6966923c9d1a5f1d71b1760a6e3aacc5742892bdcb88568f58b29605368c67e49440063b022b1885'
